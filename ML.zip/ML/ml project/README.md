# University Student Portal - ML Project

A professional Flask-based web application for student academic performance tracking and guidance.

## Project Structure
```
ml project/
├── app.py                 # Flask backend API with classification logic
├── studentpred_ml.csv     # Student dataset
├── requirements.txt       # Python dependencies
├── templates/
│   └── index.html        # Frontend HTML
└── static/
    ├── style.css         # Professional styling
    └── script.js         # Frontend JavaScript
```

## Setup Instructions for VS Code

### 1. Open the project folder in VS Code:
   - Open VS Code
   - File → Open Folder
   - Select the "ml project" folder

### 2. Install Python dependencies:
   Open terminal in VS Code (Ctrl + `) and run:
   ```bash
   pip install -r requirements.txt
   ```

### 3. Run the application:
   In the terminal, run:
   ```bash
   python app.py
   ```

### 4. Access the portal:
   Open your browser and go to:
   ```
   http://localhost:5000
   ```

## Features

### Login System
- Login with Student ID OR Name (either one is sufficient)
- Example: ID: `STD000001` or Name: `Vivaan Singh`

### Student Classification
- **Excellent** (90%+): Outstanding performance with advanced recommendations
- **Good** (75-89%): Solid performance with improvement tips
- **Average** (50-74%): Needs better focus and effort
- **Needs Improvement** (<50% or Failed): Requires extra classes and study guidance

### Dashboard Display
- Course information
- Attendance percentage
- Marks percentage
- Letter Grade (A, B, C, D, F)
- Pass/Fail status
- Personalized academic recommendations

## Professional Design
- Clean blue color theme
- Pleasant, easy-on-eyes interface
- Responsive layout
- Official university portal appearance

## Technologies Used
- Backend: Flask (Python)
- Frontend: HTML, CSS, JavaScript
- Data: Pandas for CSV processing
