from flask import Flask, render_template, request, jsonify
import pandas as pd
import os
import webbrowser
from threading import Timer

app = Flask(__name__)

# Load the dataset
csv_file = 'studentpred_ml.csv'
students_df = None

def load_data():
    global students_df
    if os.path.exists(csv_file):
        students_df = pd.read_csv(csv_file)
        return True
    return False

@app.route('/')
def index():
    load_data()
    return render_template('index.html')

@app.route('/api/login', methods=['POST'])
def login_student():
    if students_df is None:
        return jsonify({'error': 'Dataset not loaded'}), 400
    
    data = request.get_json()
    student_id = data.get('student_id', '').strip()
    name = data.get('name', '').strip()
    
    if not student_id and not name:
        return jsonify({'error': 'Please enter either Student ID or Name'}), 400
    
    # Find student by ID OR Name (case-insensitive)
    if student_id and name:
        # If both provided, match both
        student = students_df[
            (students_df['student_id'].str.lower() == student_id.lower()) &
            (students_df['name'].str.lower() == name.lower())
        ]
    elif student_id:
        # Only ID provided
        student = students_df[students_df['student_id'].str.lower() == student_id.lower()]
    else:
        # Only name provided
        student = students_df[students_df['name'].str.lower() == name.lower()]
    
    if student.empty:
        return jsonify({'error': 'Invalid credentials. Student not found.'}), 404
    
    # Get student data
    student_data = student.iloc[0].to_dict()
    
    # Classify student performance
    classification = classify_student(student_data)
    student_data['classification'] = classification
    
    return jsonify({'success': True, 'student': student_data})

def classify_student(student):
    """
    Classify student as 'Excellent', 'Good', 'Average', or 'Needs Improvement'
    Based on grade percentage, attendance, and pass/fail status
    """
    grade_percent = float(student['grade_percent'])
    attendance = float(student['attendance'])
    pass_fail = student['pass_fail']
    
    # Weaker student criteria - Failed or very low marks
    if pass_fail == 'Fail' or grade_percent < 50:
        return {
            'category': 'Needs Improvement',
            'status': 'weaker',
            'message': 'You need extra classes and proper study guidance',
            'recommendations': [
                'Mandatory attendance in remedial classes',
                'Schedule meeting with academic advisor',
                'Join peer study groups',
                'Improve attendance to at least 75% (Current: ' + str(attendance) + '%)',
                'Seek one-on-one tutoring support'
            ]
        }
    # Excellent performance - 90% and above
    elif grade_percent >= 90:
        return {
            'category': 'Excellent',
            'status': 'excellent',
            'message': 'Outstanding academic performance!',
            'recommendations': [
                'Consider mentoring struggling students',
                'Participate in academic competitions',
                'Explore research opportunities',
                'Apply for advanced courses and honors programs',
                'Maintain your excellent work ethic'
            ]
        }
    # Good performance - 75% to 89%
    elif grade_percent >= 75:
        return {
            'category': 'Good',
            'status': 'good',
            'message': 'Keep up the good work!',
            'recommendations': [
                'Maintain current study habits',
                'Aim for 90% to reach excellence',
                'Help peers in study groups',
                'Explore advanced topics in your field',
                'Participate in department projects'
            ]
        }
    # Average performance - 50% to 74%
    else:
        return {
            'category': 'Average',
            'status': 'average',
            'message': 'You can improve with better focus and effort',
            'recommendations': [
                'Increase daily study hours',
                'Maintain minimum 75% attendance',
                'Seek help from professors during office hours',
                'Practice more problems and assignments',
                'Form study groups with classmates'
            ]
        }

def open_browser():
    """Open browser after a short delay"""
    webbrowser.open('http://127.0.0.1:5000')

if __name__ == '__main__':
    load_data()
    # Open browser automatically after 1.5 seconds
    Timer(1.5, open_browser).start()
    app.run(debug=True, port=5000, use_reloader=False)
