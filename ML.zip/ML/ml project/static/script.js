// Login form handler
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const studentId = document.getElementById('studentId').value.trim();
    const studentName = document.getElementById('studentName').value.trim();
    const errorMsg = document.getElementById('errorMsg');
    
    errorMsg.textContent = '';
    
    // Check if at least one field is filled
    if (!studentId && !studentName) {
        errorMsg.textContent = 'Please enter either Student ID or Name';
        return;
    }
    
    fetch('/api/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            student_id: studentId, 
            name: studentName 
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            errorMsg.textContent = data.error;
            return;
        }
        
        if (data.success) {
            showDashboard(data.student);
        }
    })
    .catch(error => {
        errorMsg.textContent = 'Error connecting to server. Please try again.';
        console.error('Error:', error);
    });
});

// Show dashboard with student data
function showDashboard(student) {
    // Hide login section
    document.getElementById('loginSection').style.display = 'none';
    
    // Show dashboard section
    document.getElementById('dashboardSection').style.display = 'block';
    
    // Populate student data
    document.getElementById('dashStudentName').textContent = student.name;
    document.getElementById('dashStudentId').textContent = student.student_id;
    document.getElementById('dashCourse').textContent = student.course;
    document.getElementById('dashAttendance').textContent = student.attendance + '%';
    document.getElementById('dashMarks').textContent = student.grade_percent + '%';
    document.getElementById('dashLetterGrade').textContent = student.grade_letter;
    document.getElementById('dashGrade').textContent = student.pass_fail;
    
    // Set letter grade card color based on grade
    const letterGradeCard = document.getElementById('letterGradeCard');
    letterGradeCard.className = 'info-card letter-grade-card grade-' + student.grade_letter;
    
    // Set status card color based on pass/fail
    const gradeCard = document.getElementById('gradeCard');
    if (student.pass_fail === 'Pass') {
        gradeCard.classList.add('pass-grade');
        gradeCard.classList.remove('fail-grade');
    } else {
        gradeCard.classList.add('fail-grade');
        gradeCard.classList.remove('pass-grade');
    }
    
    // Display classification
    displayClassification(student.classification);
}

// Display student classification and recommendations
function displayClassification(classification) {
    const banner = document.getElementById('classificationBanner');
    const category = document.getElementById('classCategory');
    const message = document.getElementById('classMessage');
    const icon = document.getElementById('classIcon');
    const recommendationsList = document.getElementById('recommendationsList');
    
    // Set category and message
    category.textContent = classification.category;
    message.textContent = classification.message;
    
    // Set banner color and icon based on status
    banner.className = 'classification-banner ' + classification.status;
    
    switch(classification.status) {
        case 'excellent':
            icon.textContent = '🌟';
            break;
        case 'good':
            icon.textContent = '✅';
            break;
        case 'average':
            icon.textContent = '⚠️';
            break;
        case 'weaker':
            icon.textContent = '🚨';
            break;
    }
    
    // Display recommendations
    recommendationsList.innerHTML = '';
    classification.recommendations.forEach(rec => {
        const li = document.createElement('li');
        li.textContent = rec;
        recommendationsList.appendChild(li);
    });
}

// Logout handler
document.getElementById('logoutBtn').addEventListener('click', function() {
    // Hide dashboard
    document.getElementById('dashboardSection').style.display = 'none';
    
    // Show login section
    document.getElementById('loginSection').style.display = 'flex';
    
    // Clear form
    document.getElementById('loginForm').reset();
    document.getElementById('errorMsg').textContent = '';
});
